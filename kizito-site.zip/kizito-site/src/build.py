import os,json
R=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
WA="254738281177"; TEL="0738 281 177"; BOX="P.O. Box 43219, Nairobi, Kenya"
NAV=[("index.html","Home"),("tents.html","Tents & Gear"),("overlanding.html","Overlanding"),("camps.html","Camps"),("gallery.html","Gallery"),("about.html","About")]
ARW='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M4 12h16M14 6l6 6-6 6"/></svg>'
def img(n,alt,t=False,eager=False,extra=""):
    p=f"img/{'t/' if t else ''}k{n:02d}.jpg"
    return f'<img src="{p}" alt="{alt}" {"" if eager else "loading=lazy "}decoding=async {extra}>'
def simg(k,alt,t=False):
    return f'<img src="img/{"t/" if t else ""}{k}.jpg" alt="{alt}" loading=lazy decoding=async>'
def sframe(k,alt,ar="",t=False):
    return f'<div class="frame" {ar}><div class="in" data-par>{simg(k,alt,t)}</div></div>'
def frame(n,alt,ar="",t=False):
    return f'<div class="frame" {ar}><div class="in" data-par>{img(n,alt,t)}</div></div>'
def head(title,desc,page,og="img/og.jpg"):
    return f'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<title>{title}</title><meta name="description" content="{desc}"><meta name="theme-color" content="#08170f">
<meta property="og:title" content="{title}"><meta property="og:description" content="{desc}"><meta property="og:type" content="website"><meta property="og:image" content="{og}"><meta name="twitter:card" content="summary_large_image">
<link rel="icon" href="favicon.ico"><link rel="icon" type="image/png" sizes="192x192" href="img/favicon-192.png"><link rel="apple-touch-icon" href="img/apple-touch-icon.png">
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Barlow+Condensed:wght@600;700;800&family=Barlow:wght@400;500;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="css/site.css"></head><body data-page="{page}">
<a class="skip" href="#main">Skip to content</a>
<header class="nav" id="nav"><a class="brand" href="index.html" aria-label="Kizito Camping Gear home"><img src="img/logo.jpg" alt="" width="42" height="59"><span><b>KIZITO</b><small>CAMPING GEAR</small></span></a>
<button class="burger" id="burger" aria-label="Menu" aria-expanded="false"><i></i><i></i><i></i></button>
<nav class="links" id="links" aria-label="Main">{"".join(f'<a href="{h}"'+(' aria-current="page"' if h==page else '')+f'>{l}</a>' for h,l in NAV)}<a class="btn" href="contact.html">Get a Quote</a></nav></header><main id="main">'''
def foot():
    return f'''</main><footer class="foot"><div class="wrap"><div class="fgrid"><div><img class="fl" src="img/logo.jpg" alt="Kizito Camping Gear" width="120" height="170"><p><b>Engineered for the Outdoors.</b></p><p style="opacity:.7">Manufacturer · Supplier · Rental · Outdoor Outfitter</p></div>
<div><h4>Explore</h4><ul>{"".join(f'<li><a href="{h}">{l}</a></li>' for h,l in NAV)}<li><a href="contact.html">Contact</a></li></ul></div>
<div><h4>We do</h4><ul><li>Tent manufacturing</li><li>Supply &amp; rentals</li><li>Overlanding truck builds</li><li>Camp management</li></ul></div>
<div><h4>Reach us</h4><p><a href="https://wa.me/{WA}" rel="noopener">WhatsApp {TEL}</a></p><p>{BOX}</p></div></div>
<div class="fbase"><span>© <span id="yr">2026</span> Kizito Camping Gear</span><span>Some photos via Unsplash</span></div></div></footer>
<div class="lb" id="lb" role="dialog" aria-modal="true" aria-label="Photo viewer"><button class="x" aria-label="Close">×</button><button class="pv" aria-label="Previous">‹</button><figure><img alt=""><figcaption><span></span><span></span></figcaption></figure><button class="nx" aria-label="Next">›</button></div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/gsap.min.js"></script><script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/ScrollTrigger.min.js"></script><script src="https://cdn.jsdelivr.net/npm/lenis@1.1.13/dist/lenis.min.js"></script>
<script src="js/site.js"></script></body></html>'''
def cta(t="Planning a trip, camp or build?"):
    return f'<section class="cta"><div class="wrap"><h2 data-split>{t}</h2><div class="btns"><a class="btn" href="contact.html">Request a quote {ARW}</a><a class="btn ghost" href="https://wa.me/{WA}" rel="noopener">WhatsApp us</a></div></div></section>'
def phead(title,crumb,lede,n,alt):
    return f'''<section class="hero phead"><div class="hero-bg" data-heropar>{img(n,alt,eager=True,extra='fetchpriority=high')}</div><div class="wrap"><p class="crumb"><a href="index.html">Home</a> / {crumb}</p><h1 data-split>{title}</h1><p class="lede">{lede}</p></div></section>'''
pages={}

# HOME
h=head("Kizito Camping Gear | Tents, Overlanding Trucks & Camp Management, Nairobi","Kizito Camping Gear manufactures and supplies tents and camping equipment, builds overlanding trucks and manages camps in Kenya. Engineered for the Outdoors.","index.html")
h+=f'''<section class="hero"><div class="hero-bg" data-heropar>{img(1,"A long row of canvas dome tents on a Kenyan campsite",eager=True,extra="fetchpriority=high")}</div>
<div class="wrap"><div class="tags"><span>Manufacturer</span><span>Supplier</span><span>Rental</span><span>Outdoor outfitter</span></div>
<h1 class="h-xl" data-split>Engineered<br>for the <span class="gold">outdoors</span></h1>
<p class="lede">Tents, camping equipment, overlanding trucks and complete camp management, built in Nairobi for expeditions, group camps and adventure travel.</p>
<div class="btns"><a class="btn" href="contact.html">Request a quote {ARW}</a><a class="btn ghost" href="tents.html">See the range</a></div>
<div class="hero-foot"><span>Nairobi · Kenya</span><span class="cue"><i></i>Scroll</span></div></div></section>
<div class="marq" aria-hidden="true"><div class="marq-t">{"".join('<span>Tent manufacturing</span><span>Supply &amp; rentals</span><span>Safari tents</span><span>Fly camping</span><span>Overlanding trucks</span><span>Camp management</span>' for _ in range(4))}</div></div>
<section class="sec light"><div class="wrap split"><div><p class="eyebrow on-light">Who we are</p><h2 class="h-lg" data-split>More than equipment. A complete camping experience.</h2>
<p class="lede" style="margin-top:1.4rem">We manufacture, equip, establish and manage camps, delivering outdoor and overlanding solutions. Through product sales, rentals and managed camping experiences, we make outdoor adventure more accessible.</p>
<div class="btns" style="margin-top:1.6rem"><a class="btn" href="about.html">Our story {ARW}</a></div></div>
<div class="split-m" data-reveal>{sframe("s2","Canvas shelter and camp table at sunset in the highlands")}<p class="cap">Canvas camps, set up anywhere</p></div></div></section>
<section class="hdiv" id="hdiv"><div class="hdiv-pin"><div class="hdiv-head"><div><p class="eyebrow">What we do</p><h2 class="h-lg" data-split>Four ways we serve the outdoors</h2></div><div class="hdiv-prog"><i></i></div></div>
<div class="hint" id="hint" aria-hidden="true"><svg class="hand" viewBox="0 0 64 64" fill="rgba(241,233,212,.28)" stroke="rgba(241,233,212,.9)" stroke-width="2.2" stroke-linejoin="round" stroke-linecap="round"><path d="M26 8c0-3 5-3 5 0v22l1-.5c2-1 5 0 5 2l1-.5c2-1 5 0 5 2l1-.5c2-1 5 0 5 3v10c0 8-6 14-14 14h-3c-5 0-8-2-11-6L12 40c-2-3 1-6 4-4l6 6V8c0-3 4-3 4 0z"/></svg><span>Keep scrolling</span><svg class="chev" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M5 9l7 7 7-7"/></svg></div>
<div class="hdiv-track">
<a class="dcard" href="tents.html"><div class="frame"><div class="in">{img(23,"Dome tent next to a camp shower",t=True)}</div></div><div class="dcard-b"><span class="dcard-n">01</span><h3>Manufacturing</h3><p>Canvas, dome, group and expedition tents, made to take real weather.</p><span class="more">Explore tents {ARW}</span></div></a>
<a class="dcard" href="tents.html#rentals"><div class="frame"><div class="in">{img(14,"Group of dome tents set up on grass",t=True)}</div></div><div class="dcard-b"><span class="dcard-n">02</span><h3>Supply &amp; rentals</h3><p>Buy or hire tents and camping equipment for schools, groups and events.</p><span class="more">Rentals {ARW}</span></div></a>
<a class="dcard" href="overlanding.html"><div class="frame"><div class="in">{img(6,"Olive green overland expedition truck",t=True)}</div></div><div class="dcard-b"><span class="dcard-n">03</span><h3>Overlanding solutions</h3><p>Expedition trucks and passenger interiors for group travel and remote field work.</p><span class="more">See the fleet {ARW}</span></div></a>
<a class="dcard" href="camps.html"><div class="frame"><div class="in">{img(22,"Tents under acacia trees beside a lake",t=True)}</div></div><div class="dcard-b"><span class="dcard-n">04</span><h3>Camp management</h3><p>From campsite establishment to outdoor activities, we set up and support your group.</p><span class="more">Camps &amp; experiences {ARW}</span></div></a>
</div></div></section>
<section class="sec light"><div class="wrap"><div class="head"><div><p class="eyebrow on-light">Product range</p><h2 class="h-lg" data-split>Camping equipment &amp; tent solutions</h2></div><a class="btn ghost" href="tents.html">All tents {ARW}</a></div>
<div class="tgrid"><a class="tcard" href="tents.html" data-reveal>{frame(11,"Canvas safari tent",'style="aspect-ratio:4/5"',t=True)}<h3>Canvas / Safari tents</h3><p>Canvas tent installations for organised camps.</p></a>
<a class="tcard" href="tents.html" data-reveal>{frame(23,"Dome tent",'style="aspect-ratio:4/5"',t=True)}<h3>Dome tents</h3><p>Compact dome-style tents for outdoor stays.</p></a>
<a class="tcard" href="tents.html" data-reveal>{frame(14,"Group tent setup",'style="aspect-ratio:4/5"',t=True)}<h3>Group tent setups</h3><p>Multiple tents arranged for group accommodation.</p></a>
<a class="tcard" href="tents.html" data-reveal>{frame(18,"Expedition tents below Kilimanjaro",'style="aspect-ratio:4/5"',t=True)}<h3>Expedition tents</h3><p>Tent setups in highland and mountain environments.</p></a></div></div></section>
<section class="band" data-band><div class="band-bg" data-bandpar>{simg("s3","Canvas safari tent under the Milky Way at night")}</div><div class="wrap band-in"><p class="eyebrow">Canvas &amp; comfort</p><h2 class="h-lg" data-split>Sleep well, even<br>under open sky</h2><p class="lede">Roomy canvas tents that stay dry, shaded and comfortable from the first night to the last.</p><a class="btn" href="tents.html">See our tents {ARW}</a></div></section>
<section class="pan" id="pan"><div class="pan-img"><img src="img/fleet-wide.jpg" alt="Four Scania overland trucks parked in a row" loading="lazy"></div>
<div class="pan-t"><p class="eyebrow">Overlanding</p><h2 class="h-lg" data-split>Built to go<br>where roads end</h2></div>
<div class="pan-b"><p>Kizito's expedition fleet and vehicle interiors for group travel, field operations and remote outdoor experiences.</p><a class="btn" href="overlanding.html">Meet the fleet {ARW}</a></div></section>
<section class="sec dark topo"><div class="wrap"><div class="head"><div><p class="eyebrow">Outdoor experiences</p><h2 class="h-lg" data-split>Real places. Real adventures.</h2></div><a class="btn ghost" href="camps.html">Camp support {ARW}</a></div>
<div class="exp"><div class="it w" data-reveal>{sframe("s1","Hikers climbing a mountain trail on Kilimanjaro",t=True)}<h3>Mountain camping</h3><p>Camping in highland environments.</p></div>
<div class="it" data-reveal>{frame(16,"Hikers on a rock above a pine forest",t=True)}<h3>Hiking &amp; exploration</h3><p>Outdoor walks and exploration.</p></div>
<div class="it" data-reveal>{frame(22,"Tents beside the lake",t=True)}<h3>Campsite experiences</h3><p>Tent setups in a natural setting.</p></div></div></div></section>
<section class="band cheetah" data-band><div class="band-bg" data-bandpar>{simg("s5","Cheetah watching over the Kenyan plains from a termite mound")}</div><div class="wrap band-in"><p class="eyebrow">Safari tents &amp; fly camping</p><h2 class="h-lg" data-split>Camp where<br>the wild is</h2><p class="lede">Light safari tents and fly camping set-ups take your group right into wildlife country, then pack away without a trace.</p><a class="btn" href="camps.html#fly">Fly camping {ARW}</a></div></section>
<section class="sec dark alt"><div class="wrap"><div class="vmp"><div data-reveal><span class="n">01</span><h3>Our vision</h3><p>To be the most trusted provider of affordable, reliable and quality camping services and outdoor gear.</p></div>
<div data-reveal><span class="n">02</span><h3>Our mission</h3><p>To share our passion for camping and inspire people to experience outdoor adventure, offering quality camping services at affordable prices.</p></div>
<div data-reveal><span class="n">03</span><h3>Our purpose</h3><p>To build a business that makes a difference in people's lives.</p></div></div></div></section>
{cta()}'''
pages["index.html"]=h+foot()

# TENTS
h=head("Tents & Camping Gear | Kizito Camping Gear","Canvas safari tents, dome tents, group tent setups and expedition tents, manufactured, supplied and rented by Kizito Camping Gear in Nairobi.","tents.html")
h+=phead("Tents &amp; camping gear","Tents &amp; gear","Camping equipment and practical outdoor solutions for expeditions, group camps and adventure travel.",1,"Row of canvas tents on grass")
prods=[("Canvas / Safari tents","Canvas tent installations for organised camps. Roomy, shaded and set up with real furniture, they suit lodges, group camps, longer stays and fly camping safaris.",11,"Canvas safari tent with table and chairs"),
("Dome tents","Compact dome-style tents for outdoor stays. Quick to pitch and easy to carry, with a camp shower option alongside.",23,"Dome tent with a camp shower"),
("Group tent setups","Multiple tents arranged for group accommodation, from school trips to corporate retreats.",14,"Many dome tents on a lawn"),
("Expedition tents","Tent setups in highland and mountain environments, ready for wind, cold and altitude.",18,"Orange expedition tents below Kilimanjaro")]
h+='<section class="sec light"><div class="wrap"><p class="eyebrow on-light">The range</p><h2 class="h-lg" data-split style="margin-bottom:2rem">Four tent families</h2>'
for i,(t,d,n,a) in enumerate(prods,1):
    h+=f'<article class="prow" data-reveal><div class="num">0{i}</div><div><h3>{t}</h3><p>{d}</p><div class="btns" style="margin-top:1.4rem"><a class="btn ghost" href="contact.html">Ask about {t.split(" ")[0].lower()} {ARW}</a></div></div>{frame(n,a)}</article>'
h+='</div></section>'
h+=f'''<section class="sec dark topo" id="rentals"><div class="wrap"><p class="eyebrow">How we work with you</p><h2 class="h-lg" data-split style="margin-bottom:2.2rem">Make it, supply it, rent it</h2>
<div class="cards3"><div class="card" data-reveal><span class="n">01</span><h3>Manufacturing</h3><p>Tents made in-house, so sizes and fittings can be adapted to your camp.</p></div><div class="card" data-reveal><span class="n">02</span><h3>Supply</h3><p>Camping equipment and outdoor gear supplied at affordable prices.</p></div><div class="card" data-reveal><span class="n">03</span><h3>Rentals</h3><p>Hire tents and gear for a trip or an event, without buying.</p></div></div></div></section>
<section class="sec light"><div class="wrap"><p class="eyebrow on-light">In the field</p><h2 class="h-md" data-split style="margin-bottom:1.6rem">Our tents on location</h2><div class="strip">{frame(1,"Tent row",t=True)}{frame(13,"Camp in trees",t=True)}{frame(15,"Tents near a thatched hut",t=True)}{frame(12,"Summit camp above clouds",t=True)}</div></div></section>
<section class="band short" data-band><div class="band-bg" data-bandpar>{simg("s3","Canvas tent under the stars")}</div><div class="wrap band-in"><p class="eyebrow">Made for the long nights</p><h2 class="h-md" data-split>Camp comfort, canvas strong</h2></div></section>
{cta("Need tents for your next camp?")}'''
pages["tents.html"]=h+foot()

# OVERLANDING
h=head("Overlanding Truck Solutions | Kizito Camping Gear","Expedition trucks, passenger interiors and seating configurations for group travel, field operations and remote outdoor experiences.","overlanding.html")
h+=phead("Overlanding truck solutions","Overlanding","Kizito's expedition fleet and vehicle interiors for group travel, field operations and remote outdoor experiences.",8,"Scania overland trucks parked in a row")
h+=f'''<section class="sec light"><div class="wrap split"><div><p class="eyebrow on-light">Vehicles, interiors &amp; outfitting</p><h2 class="h-lg" data-split>Trucks built for the long way round</h2><p class="lede" style="margin-top:1.4rem">We build and outfit overlanding trucks: the body, the seating, the storage and the details that make remote travel comfortable for a whole group.</p><div class="pill-row"><span class="pill">Expedition vehicles</span><span class="pill">Passenger interiors</span><span class="pill">Seating layouts</span></div></div><div class="split-m" data-reveal>{frame(6,"Olive Scania expedition truck")}<p class="cap">Expedition vehicle</p></div></div></section>
<section class="sec dark topo"><div class="wrap"><p class="eyebrow">Inside the truck</p><h2 class="h-lg" data-split style="margin-bottom:2rem">Passenger interiors &amp; seating</h2><div class="exp"><div class="it w" data-reveal>{frame(2,"Interior with seats around a table",t=True)}<h3>Lounge &amp; dining</h3><p>Seats around a table for meals and planning.</p></div><div class="it" data-reveal>{frame(4,"Rows of cream quilted seats",t=True)}<h3>Seating configuration</h3><p>Quilted rows for group travel.</p></div><div class="it" data-reveal>{frame(5,"Interior with window seating and tables",t=True)}<h3>Passenger interior</h3><p>Wide windows for the view.</p></div><div class="it" data-reveal>{frame(7,"Interior bench seating",t=True)}<h3>Bench seating</h3><p>Open layouts with storage.</p></div><div class="it" data-reveal>{frame(3,"Interior cab detail with equipment locker",t=True)}<h3>Equipment storage</h3><p>Secure lockers inside the cabin.</p></div></div></div></section>
<section class="sec light"><div class="wrap"><p class="eyebrow on-light">The fleet</p><h2 class="h-md" data-split style="margin-bottom:1.6rem">On the road</h2><div class="strip">{frame(6,"Truck side view",t=True)}{frame(17,"White overland truck under trees",t=True)}{frame(21,"People watching a truck",t=True)}{frame(8,"Four trucks in a row",t=True)}</div></div></section>
<section class="band short" data-band><div class="band-bg" data-bandpar>{simg("s6","Expedition vehicle raising dust across open country at sunset")}</div><div class="wrap band-in"><p class="eyebrow">Wherever the road leads</p><h2 class="h-md" data-split>Out past the last tarmac</h2></div></section>
{cta("Planning an overland trip or truck build?")}'''
pages["overlanding.html"]=h+foot()

# CAMPS
h=head("Camp Management & Outdoor Experiences | Kizito Camping Gear","From campsite establishment to outdoor activities, Kizito brings together the equipment, setups and support for group adventures.","camps.html")
h+=phead("Camp management &amp; outdoor experiences","Camps","From campsite establishment to outdoor activities, Kizito brings together the equipment, setups and support for group adventures.",20,"Children in life jackets on a boat")
h+=f'''<section class="sec light"><div class="wrap split"><div><p class="eyebrow on-light">Camp support</p><h2 class="h-lg" data-split>We set it up. You enjoy it.</h2><p class="lede" style="margin-top:1.4rem">We establish and manage campsites: tents, furniture, logistics and support, so groups can focus on the activity. Plan your next outdoor experience with Kizito.</p><div class="btns" style="margin-top:1.6rem"><a class="btn" href="contact.html">Plan your trip {ARW}</a></div></div><div class="split-m" data-reveal>{frame(22,"Camp beside the lake")}<p class="cap">Campsite experiences</p></div></div></section>
<section class="sec dark topo"><div class="wrap"><p class="eyebrow">Outdoor experiences &amp; camp support</p><h2 class="h-lg" data-split style="margin-bottom:2rem">Real activities, real locations</h2><div class="cards3"><div class="card" data-reveal><span class="n">01</span><h3>Hiking &amp; exploration</h3><p>Outdoor walks and exploration.</p></div><div class="card" data-reveal><span class="n">02</span><h3>Mountain camping</h3><p>Camping in highland environments.</p></div><div class="card" data-reveal><span class="n">03</span><h3>Campsite experiences</h3><p>Tent setups in a natural setting.</p></div></div>
<div class="strip" style="margin-top:clamp(20px,3vw,40px)">{frame(16,"Hikers",t=True)}{sframe("s1","Hikers on Kilimanjaro",t=True)}{frame(19,"Hippos in the lake",t=True)}{sframe("s7","Camp tucked into a green valley",t=True)}</div></div></section>
<section class="sec dark topo" id="fly"><div class="wrap split flip"><div class="split-m" data-reveal>{sframe("s5","Cheetah on a termite mound",'style="aspect-ratio:4/5"')}<p class="cap">Wildlife country</p></div><div><p class="eyebrow">Safari tents &amp; fly camping</p><h2 class="h-lg" data-split>Fly camping, the wild way</h2><p class="lede" style="margin-top:1.4rem">Fly camping brings the camp to the wildlife: light, quick-to-pitch safari tents set up in open country, then packed away when the adventure moves on.</p><div class="pill-row"><span class="pill">Safari tents</span><span class="pill">Fly camping</span><span class="pill">Camp setup &amp; support</span></div><div class="btns" style="margin-top:1.6rem"><a class="btn" href="contact.html">Plan a fly camp {ARW}</a></div></div></div></section>
<section class="sec light"><div class="wrap split flip"><div><p class="eyebrow on-light">After the day</p><h2 class="h-lg" data-split>Evenings around the fire</h2><p class="lede" style="margin-top:1.4rem">A managed camp is more than tents. We help set up the campsite so your group ends every day around the fire, fed, warm and ready for the next adventure.</p></div><div class="split-m" data-reveal>{sframe("s4","Campfire burning at dusk with acacia trees behind",'style="aspect-ratio:4/5"')}</div></div></section>
{cta("Plan your next outdoor experience with Kizito")}'''
pages["camps.html"]=h+foot()

# GALLERY
cats={"tents":[1,11,13,14,15,22,23],"trucks":[2,3,4,5,6,7,8,17,21],"outdoors":[9,10,12,16,18,19,20,24]}
caps={1:"Tent row",2:"Passenger interior",3:"Cabin storage",4:"Seating configuration",5:"Passenger interior",6:"Expedition vehicle",7:"Bench seating",8:"Kizito fleet",9:"Mountain camp",10:"Mount Kenya",11:"Safari tent",12:"Summit camp",13:"Campsite",14:"Group tent setup",15:"Group camp",16:"Hiking",17:"Overland truck",18:"Expedition tents",19:"Lake wildlife",20:"Boat outing",21:"Fleet visit",22:"Lakeside camp",23:"Dome tent",24:"Lake walk"}
cat_of={n:c for c,l in cats.items() for n in l}
h=head("Gallery | Kizito Camping Gear","Photos of Kizito tents, overlanding trucks, camps and outdoor experiences.","gallery.html")
h+=phead("Gallery","Gallery","Tents, trucks, camps and the places they take people.",9,"Mountain camp in the mist")
h+='<section class="sec light"><div class="wrap"><div class="filters" role="group" aria-label="Filter photos"><button class="fbtn" data-f="all" aria-pressed="true">All</button><button class="fbtn" data-f="tents" aria-pressed="false">Tents</button><button class="fbtn" data-f="trucks" aria-pressed="false">Trucks</button><button class="fbtn" data-f="outdoors" aria-pressed="false">Outdoors</button></div><div class="mason" id="mason">'
for n in range(1,25):
    h+=f'<button class="gt" data-c="{cat_of[n]}" data-full="img/k{n:02d}.jpg" data-cap="{caps[n]}"><img src="img/t/k{n:02d}.jpg" alt="{caps[n]}" loading="lazy" decoding="async"><span>{caps[n]}</span></button>'
h+='</div></div></section>'+cta("Like what you see?")
pages["gallery.html"]=h+foot()

# ABOUT
h=head("About | Kizito Camping Gear","Kizito Camping Gear is an outdoor equipment manufacturer, supplier and outfitter specialising in tents, overlanding truck builds and camp management.","about.html")
h+=phead("About Kizito","About","An outdoor equipment manufacturer, supplier and outfitter based in Nairobi.",13,"Camp among trees")
h+=f'''<section class="sec light"><div class="wrap split"><div><p class="eyebrow on-light">Who we are</p><h2 class="h-lg" data-split>Passion for camping, made accessible</h2><p class="lede" style="margin-top:1.4rem">Kizito Camping Gear is an outdoor equipment manufacturer, supplier and outfitter specialising in camping solutions, tent manufacturing, overlanding truck builds and complete camp management. Through product sales, rentals and managed camping experiences, we make outdoor adventure more accessible.</p></div><div class="split-m" data-reveal>{frame(11,"Safari tent at Kizito campsite",'style="max-width:520px"')}<p class="cap">Kizito campsite installation</p></div></div></section>
<section class="sec dark topo"><div class="wrap"><div class="bignum"><div><b>Manufacturing</b><span>Tents made in-house</span></div><div><b>Supply &amp; rentals</b><span>Buy or hire gear</span></div><div><b>Overlanding</b><span>Truck builds &amp; interiors</span></div><div><b>Camp management</b><span>Setup &amp; support</span></div></div>
<div class="vmp" style="margin-top:clamp(40px,6vw,90px)"><div><span class="n">01</span><h3>Our vision</h3><p>To be the most trusted provider of affordable, reliable and quality camping services and outdoor gear.</p></div><div><span class="n">02</span><h3>Our mission</h3><p>To share our passion for camping and inspire people to experience outdoor adventure, offering quality camping services at affordable prices.</p></div><div><span class="n">03</span><h3>Our purpose</h3><p>To build a business that makes a difference in people's lives.</p></div></div></div></section>{cta("Let's plan your next adventure")}'''
pages["about.html"]=h+foot()

# CONTACT
h=head("Contact | Kizito Camping Gear","Request a quote for tents, camping gear, overlanding trucks or camp management. Call or WhatsApp Kizito Camping Gear in Nairobi.","contact.html")
h+=phead("Get a quote","Contact","Tell us what you need and we will come back to you.",15,"Camp with a thatched hut")
h+=f'''<section class="sec light"><div class="wrap cgrid"><div class="cdet"><div><h3>Call or WhatsApp</h3><a href="tel:+{WA}">{TEL}</a></div><div><h3>Postal address</h3><p>P.O. Box 43219<br>Nairobi, Kenya</p></div><p class="sm muted">Tell us what you need and we will respond on WhatsApp.</p></div>
<form class="form" id="qf" novalidate><h2>Request a quote</h2><div class="two"><label>Your name<input name="name" required autocomplete="name"></label><label>Phone<input name="phone" type="tel" autocomplete="tel"></label></div>
<label>I am interested in<select name="topic"><option>Tents &amp; camping gear</option><option>Tent rental</option><option>Overlanding truck / interior</option><option>Camp management</option><option>Something else</option></select></label>
<label>Message<textarea name="msg" placeholder="Dates, group size, location, anything useful"></textarea></label><p class="err" id="err" role="alert"></p>
<button class="btn" type="submit">Send on WhatsApp {ARW}</button><p class="fnote">This opens WhatsApp with your message ready to send.</p></form></div></section>'''
pages["contact.html"]=h+foot()
for k,v in pages.items(): open(os.path.join(R,k),"w").write(v)
open(os.path.join(R,"robots.txt"),"w").write("User-agent: *\nAllow: /\n")
print("built",len(pages))
